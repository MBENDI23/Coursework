class TicketQueue {
    constructor() {
        this.queue = [];
    }

    arrive(customerName) {
        this.queue.push(customerName);
        this.updateQueueDisplay();
    }

    purchase() {
        if (this.queue.length > 0) {
            this.queue.shift(); // Remove the first customer
            this.updateQueueDisplay();
        }
    }

    updateQueueDisplay() {
        const queueDiv = document.getElementById('queue');
        queueDiv.innerHTML = this.queue
            .map(customer => `<div>${customer}</div>`)
            .join('');
        document.getElementById('purchaseBtn').disabled = this.queue.length === 0;
    }
}

const ticketQueue = new TicketQueue();

document.getElementById('arriveBtn').addEventListener('click', () => {
    const customerName = `Customer ${Math.floor(Math.random() * 1000)}`;
    ticketQueue.arrive(customerName);
});

document.getElementById('purchaseBtn').addEventListener('click', () => {
    ticketQueue.purchase();
});