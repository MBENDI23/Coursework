alert("you are welcome to our Simplified Web Browser Navigation");
class BrowserHistory {
    constructor() {
        this.historyStack = [];
        this.currentIndex = -1;
    }

    visit(url) {
        // Remove any forward history when visiting a new page
        this.historyStack = this.historyStack.slice(0, this.currentIndex + 1);
        this.historyStack.push(url);
        this.currentIndex++;
        this.updateHistory();
        
    }

    back() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.updateHistory();
        }
    }

    forward() {
        if (this.currentIndex < this.historyStack.length - 1) {
            this.currentIndex++;
            this.updateHistory();
        }
    }

    updateHistory() {
        const historyDiv = document.getElementById('history');
        historyDiv.innerHTML = this.historyStack
            .map((url, index) => `<div style="color: ${index === this.currentIndex ? 'blue' : 'black'};">${url}</div>`)
            .join('');
        document.getElementById('backBtn').disabled = this.currentIndex <= 0;
        document.getElementById('forwardBtn').disabled = this.currentIndex >= this.historyStack.length - 1;
    }
}

const browserHistory = new BrowserHistory();

document.getElementById('visitBtn').addEventListener('click', () => {
    const urlInput = document.getElementById('urlInput');
    const url = urlInput.value.trim();
    if (url) {
        browserHistory.visit(url);
        urlInput.value = '';
    }
});

document.getElementById('backBtn').addEventListener('click', () => {
    browserHistory.back();
});

document.getElementById('forwardBtn').addEventListener('click', () => {
    browserHistory.forward();
});
