class SongNode {
    constructor(title, artist, duration) {
        this.title = title;
        this.artist = artist;
        this.duration = duration;
        this.next = null;
    }
}

class Playlist {
    constructor() {
        this.head = null;
        this.tail = null;
        this.currentIndex = -1;
        this.size = 0;
    }

    addSong(title, artist, duration) {
        const newSong = new SongNode(title, artist, duration);
        if (!this.head) {
            this.head = newSong;
            this.tail = newSong;
        } else {
            this.tail.next = newSong;
            this.tail = newSong;
        }
        this.size++;
        this.updatePlaylistDisplay();
    }

    removeSong(index) {
        if (index < 0 || index >= this.size) return;

        if (index === 0) {
            this.head = this.head.next;
        } else {
            let current = this.head;
            for (let i = 0; i < index - 1; i++) {
                current = current.next;
            }
            current.next = current.next ? current.next.next : null;
            if (index === this.size - 1) {
                this.tail = current;
            }
        }
        this.size--;
        this.currentIndex = Math.min(this.currentIndex, this.size - 1);
        this.updatePlaylistDisplay();
    }

    playSong() {
        if (this.currentIndex >= 0) {
            const currentSong = this.getSongAt(this.currentIndex);
            alert(`Playing: ${currentSong.title} by ${currentSong.artist} (${currentSong.duration})`);
        }
    }

    previousSong() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
        }
        this.updateButtons();
    }

    nextSong() {
        if (this.currentIndex < this.size - 1) {
            this.currentIndex++;
        }
        this.updateButtons();
    }

    getSongAt(index) {
        let current = this.head;
        for (let i = 0; i < index; i++) {
            if (current) current = current.next;
        }
        return current;
    }

    updatePlaylistDisplay() {
        const playlistDiv = document.getElementById('playlist');
        playlistDiv.innerHTML = '';
        let current = this.head;
        let index = 0;
        while (current) {
            playlistDiv.innerHTML += `<div>${index + 1}: ${current.title} by ${current.artist} (${current.duration})</div>`;
            current = current.next;
            index++;
        }
        this.updateButtons();
    }

    updateButtons() {
        document.getElementById('removeBtn').disabled = this.size === 0;
        document.getElementById('playBtn').disabled = this.currentIndex < 0;
        document.getElementById('prevBtn').disabled = this.currentIndex <= 0;
        document.getElementById('nextBtn').disabled = this.currentIndex >= this.size - 1;
    }
}

const playlist = new Playlist();

document.getElementById('addBtn').addEventListener('click', () => {
    const title = document.getElementById('titleInput').value.trim();
    const artist = document.getElementById('artistInput').value.trim();
    const duration = document.getElementById('durationInput').value.trim();
    if (title && artist && duration) {
        playlist.addSong(title, artist, duration);
        document.getElementById('titleInput').value = '';
        document.getElementById('artistInput').value = '';
        document.getElementById('durationInput').value = '';
    }
});

document.getElementById('removeBtn').addEventListener('click', () => {
    playlist.removeSong(playlist.currentIndex);
});

document.getElementById('playBtn').addEventListener('click', () => {
    playlist.playSong();
});

document.getElementById('prevBtn').addEventListener('click', () => {
    playlist.previousSong();
});

document.getElementById('nextBtn').addEventListener('click', () => {
    playlist.nextSong();
});